## File list
### x_train: all features exclude profit class and box office, movies 1997 to 2015
### x_test: all features exclude profit class and box office, movies 2016 to 2017
### y_classification_train: profit class, movies 1997~2015, used to train classification model
### y_classification_test: profit class, movies 1997~2015, used to test classification model
### y_regression_train: box office, movies 1997~2015, used to train classification model
### y_regression_test: box office, movies 1997~2015, used to test classification model
